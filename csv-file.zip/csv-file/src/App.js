import React, { useReducer } from "react";
import { parse } from "papaparse";
import 'bootstrap/dist/css/bootstrap.css';

const callApi=(name, email, index)=> {
  setTimeout(() => {
    var form_data = new FormData();
  var objectURL
  form_data.append("url", `http://alive5.com/xyz123?firstname=${name}&email=${email}`);
  console.log(form_data)
  const request = {
    method: 'POST',
    body: form_data,
    headers: {
      'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjcmVhdGVkIjoxNTEyMTUwODk2NDc4LCJlbWFpbCI6InRlc3Rjb0BtYWlsaW5hdG9yLmNvbSIsIm9yZ05hbWUiOiJ0ZXN0Y28iLCJwYXNzd29yZCI6Ik5hTmFJTGJGb1VPV3V2TUsxd3AxS2xWeDVxMjFLeUhMS01LcmtPVmVNOTYzMTlMdXRIaEcrS3psbTlhSnFnPSIsInByb2ZpbGVJbWFnZSI6ImZhY2Vib29rX3Bob3RvLnBuZyIsInJvbGUiOiJtYXN0ZXIiLCJzY3JlZW5OYW1lIjoidGVzdGNvIiwic3RhdHVzIjoibGl2ZSIsInVzZXJFbWFpbCI6InRlc3Rjb0BtYWlsaW5hdG9yLmNvbSIsInVzZXJJZCI6IjMwNjA1ODNhLWJiMjctNDU4YS1iZTE3LTkxYThhYmNhNzRlYSIsImlhdCI6MTUxMjEzMjg5N30.-tc-ZjbTw20mKaXJaSl6tOw8w5hkm584Q-TsFInCUbo'
    }
  }
  var myImage = document.querySelector('#img' + index);
  console.log(request)
  fetch('https://api.alive5.com/1.0/qr/create', request).then(function (response) {
    return response.blob();
  }).then(function (myBlob) {
    console.log('myblob', myBlob)
    objectURL = URL.createObjectURL(myBlob);
    console.log('myblob objectURL', objectURL)
    myImage.src = objectURL
  });
  }, 100);
}

export default function App() {
  const [highlighted, setHighlighted] = React.useState(false);
  const [contacts, setContacts] = React.useState([
    { email: "fake@gmail.com", name: "Fake" },
  ]);
  console.log("the contacts are", contacts)
  return (
    <div>
      <h1 className="text-center text-4xl">Drag a file here:</h1>
      <div
        className={`p-6 my-2 mx-auto max-w-md border-2 ${
          highlighted ? "border-green-600 bg-green-100" : "border-gray-600"
          }`}
        onDragEnter={() => {
          setHighlighted(true);
        }}
        onDragLeave={() => {
          setHighlighted(false);
        }}
        onDragOver={(e) => {
          e.preventDefault();
        }}
        onDrop={(e) => {
          e.preventDefault();
          setHighlighted(false);

          Array.from(e.dataTransfer.files)
            .filter((file) => file.type === "text/csv")
            .forEach(async (file) => {
              const text = await file.text();
              const result = parse(text, { header: true });
              setContacts((existing) => [...existing, ...result.data]);
            });
        }}
      >
        DROP HERE
      </div>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Email</th>
            <th scope="col">QR-CODE</th>
          </tr>
        </thead>
        <tbody>
          {contacts.map((contact, index) => {
            if(contact.__parsed_extra) {callApi(contact.__parsed_extra[0], contact.__parsed_extra[1], index)}
            return <> {
              contact.__parsed_extra
              &&
              <tr key={index}>
                <th scope="row">{index + 1}</th>
                <td>{contact.__parsed_extra[0]}</td>
                <td>{contact.__parsed_extra[1]}</td>
                <td> <img id={'img' + index}  style={{width:300}} /></td>
              </tr>
            }
            </>
          })}
        </tbody>
      </table>
      {/* <img id="img" /> */}
    </div>
  );
}


